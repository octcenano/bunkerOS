#!/usr/bin/env bash
set -euo pipefail

echo "=== BunkerOS Secure ISO Generator (v1.2.0) ==="
if [ "$EUID" -ne 0 ]; then
  echo "Error: Requiere permisos de root (sudo) para ejecutar mkarchiso."
  exit 1
fi

if ! command -v mkarchiso &> /dev/null; then
    echo "[+] Instalando archiso..."
    pacman -S --needed --noconfirm archiso
fi

WORKDIR="/tmp/archiso-bunker-v1.2"
OUTDIR="./out"
LOGFILE="build-iso.log"

echo "[+] Creando directorio de salida y limpiando workspace controlado..."
mkdir -p "$OUTDIR"
if [ -d "$WORKDIR" ]; then
    rm -rf "$WORKDIR"
fi
mkdir -p "$WORKDIR"

echo "[+] Compilando ISO con Perfil BunkerOS (Zen Kernel)... Log en $LOGFILE"
mkarchiso -v -w "$WORKDIR" -o "$OUTDIR" ./archiso_profile 2>&1 | tee "$LOGFILE"

echo "[+] ¡ISO construida exitosamente en $OUTDIR!"
