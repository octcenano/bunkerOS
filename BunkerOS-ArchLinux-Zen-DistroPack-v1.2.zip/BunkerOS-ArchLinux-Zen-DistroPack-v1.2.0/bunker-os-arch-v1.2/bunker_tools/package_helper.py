"""Arch Linux Pacman & AUR helper integration module with interactive confirmation."""
import subprocess
import shutil

class ArchPackageManager:
    def __init__(self):
        self.aur_helper = "yay" if shutil.which("yay") else ("paru" if shutil.which("paru") else None)

    def confirm_action(self, prompt):
        choice = input(f"[BunkerOS] {prompt} [s/N]: ").strip().lower()
        return choice in ["s", "si", "sí", "y", "yes"]

    def install_packages(self, packages):
        print(f"[+] Paquetes solicitados: {', '.join(packages)}")
        if not self.confirm_action("¿Deseas proceder con la instalación de estos paquetes?"):
            print("[-] Operación cancelada por el usuario.")
            return False
        
        cmd = ["sudo", "pacman", "-S", "--needed"] + packages
        return subprocess.run(cmd).returncode == 0

    def update_system(self):
        print("[+] Se actualizará el sistema y repositorios de Arch Linux.")
        if not self.confirm_action("¿Estás seguro de actualizar el sistema completo?"):
            print("[-] Actualización cancelada.")
            return False
        return subprocess.run(["sudo", "pacman", "-Syu"]).returncode == 0
