"""Valencia Weather Agent (Opt-in public JSON collector)."""
from urllib.request import Request, urlopen
from urllib.parse import urlparse
import json

def fetch_weather(url: str = "https://api.open-meteo.com/v1/forecast?latitude=39.4699&longitude=-0.3763&current=temperature_2m,relative_humidity_2m,wind_speed_10m") -> dict:
    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise ValueError("Solo URLs HTTPS")
    req = Request(url, headers={"User-Agent": "BunkerOS-Meteo/1.2.0"})
    with urlopen(req, timeout=5) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return {"location": "Valencia", "source": parsed.netloc, "data": data}
