"""Adaptive hardware profiling and AI model local advisor."""
def recommend(ram_gib: float, cpu_threads: int, purpose: str = "general") -> dict:
    if ram_gib <= 0 or cpu_threads <= 0:
        raise ValueError("RAM y número de hilos deben ser positivos")
    if ram_gib < 4:
        tier, context, note = "ultraligero", 1024, "Prioriza herramientas pequeñas; hardware limitado (Celeron / ~3.6GB RAM)."
    elif ram_gib < 8:
        tier, context, note = "ligero", 2048, "Prueba cuantización conservadora (Q4_K_M)."
    else:
        tier, context, note = "equilibrado", 4096, "Rendimiento óptimo para desarrollo y análisis."
    return {"purpose": purpose, "tier": tier, "suggested_context_tokens": context,
            "cpu_threads_cap": max(1, min(cpu_threads, 2)), "auto_download": False, "note": note}
