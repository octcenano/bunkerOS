"""CLI Entrypoint for BunkerOS v1.2.0."""
import sys
import argparse
import json
from bunker_tools.package_helper import ArchPackageManager
from bunker_tools.sentinel import ArchSentinel
from bunker_tools.adapt import recommend
from bunker_tools.board import make_board
from bunker_tools.meteo import fetch_weather

def main():
    parser = argparse.ArgumentParser(description="BunkerOS Management CLI (v1.2.0)")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("check", help="Auditoría de seguridad Sentinel")
    sub.add_parser("update", help="Actualizar sistema interactivamente")
    
    inst = sub.add_parser("install", help="Instalar paquetes")
    inst.add_argument("packages", nargs="+")

    ad = sub.add_parser("adapt", help="Recomendación de hardware/modelo")
    ad.add_argument("--ram", type=float, required=True)
    ad.add_argument("--threads", type=int, required=True)
    ad.add_argument("--purpose", default="general")

    br = sub.add_parser("board", help="Crear pizarra OSINT")
    br.add_argument("--title", default="Investigación")
    br.add_argument("--note", action="append", default=[])
    br.add_argument("--url", action="append", default=[])
    br.add_argument("--out", default="board.md")

    sub.add_parser("meteo", help="Obtener meteo Valencia")

    args = parser.parse_args()
    pkg = ArchPackageManager()
    sentinel = ArchSentinel()

    if args.command == "check":
        sec = sentinel.check_security()
        for k, v in sec.items():
            print(f"{k}: {v}")
    elif args.command == "update":
        pkg.update_system()
    elif args.command == "install":
        pkg.install_packages(args.packages)
    elif args.command == "adapt":
        print(json.dumps(recommend(args.ram, args.threads, args.purpose), indent=2))
    elif args.command == "board":
        content = make_board(args.title, args.note, args.url)
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"Pizarra guardada en {args.out}")
    elif args.command == "meteo":
        print(json.dumps(fetch_weather(), indent=2))

if __name__ == "__main__":
    main()
