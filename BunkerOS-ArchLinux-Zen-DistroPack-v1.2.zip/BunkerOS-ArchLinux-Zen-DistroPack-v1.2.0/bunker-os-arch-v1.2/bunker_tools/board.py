"""OSINT / OPSEC investigation board generator."""
from datetime import datetime, timezone
from urllib.parse import urlparse

def make_board(title: str, notes: list[str], urls: list[str]) -> str:
    safe_title = title.strip() or "Pizarra OSINT/OPSEC"
    lines = [f"# {safe_title}", "", f"Generado: {datetime.now(timezone.utc).isoformat()}", "", "> Fuentes públicas y verificación ética.", "", "## Notas y Hechos"]
    lines.extend(f"- {n.strip()}" for n in notes if n.strip())
    lines += ["", "## URLs Públicas"]
    for url in urls:
        parsed = urlparse(url.strip())
        if parsed.scheme == "https" and parsed.netloc:
            lines.append(f"- [{parsed.netloc}]({url.strip()}) — verificado")
        else:
            lines.append(f"- OMITIDA (No HTTPS): `{url.strip()}`")
    return "\n".join(lines)
