"""System Health & Hardening Sentinel for Arch Linux (v1.2.0)."""
import os
import shutil
import subprocess

class ArchSentinel:
    def check_security(self):
        nft_bin = shutil.which("nft")
        nft_status = "no instalado"
        nft_active = False

        if nft_bin:
            res = subprocess.run(["systemctl", "is-active", "nftables"], capture_output=True, text=True)
            status_out = res.stdout.strip()
            if status_out == "active":
                nft_active = True
                nft_status = "activo"
            elif status_out == "inactive":
                nft_status = "inactivo"
            else:
                nft_status = status_out or "desconocido"

        microcode_found = os.path.exists("/boot/intel-ucode.img") or os.path.exists("/boot/amd-ucode.img")
        uname_release = subprocess.run(["uname", "-r"], capture_output=True, text=True).stdout
        is_zen = "zen" in uname_release.lower()

        status = {
            "kernel_zen": is_zen,
            "firewall_nftables_bin": nft_bin is not None,
            "firewall_state": nft_status,
            "firewall_active": nft_active,
            "microcode": microcode_found,
            "archiso_ready": shutil.which("mkarchiso") is not None
        }
        return status
