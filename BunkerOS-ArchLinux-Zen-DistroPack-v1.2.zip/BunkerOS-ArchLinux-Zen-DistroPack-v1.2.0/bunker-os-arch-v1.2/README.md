# Búnker OS - Distribución Arch Linux Segura y Ligera (v1.2.0)

Distribución basada en Arch Linux diseñada para rendimiento, seguridad y equipos modestos (Intel Celeron, ~3.6GB RAM).

## 🚀 Inicio Rápido
```bash
python3 -m unittest discover -s tests -v
python3 -m bunker_tools.cli --help
```
