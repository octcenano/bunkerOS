import unittest
from bunker_tools.adapt import recommend
from bunker_tools.board import make_board
from bunker_tools.sentinel import ArchSentinel
from bunker_tools.meteo import fetch_weather

class BunkerTests(unittest.TestCase):
    def test_adapt(self):
        r = recommend(3.5, 2, "test")
        self.assertEqual(r["tier"], "ultraligero")
    def test_board(self):
        out = make_board("Test", ["nota 1"], ["https://example.com"])
        self.assertIn("nota 1", out)
    def test_sentinel(self):
        s = ArchSentinel().check_security()
        self.assertIsInstance(s, dict)
        self.assertIn("firewall_state", s)
    def test_meteo_url_validation(self):
        # Comprobar que meteo maneja correctamente la estructura
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()
