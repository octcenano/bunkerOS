#!/usr/bin/env bash
iso_name="bunker-os"
iso_label="BUNKER_OS_$(date +%Y%m)"
iso_publisher="BunkerOS Team <https://bunkeros.org>"
iso_application="BunkerOS Live/Rescue/Desktop ISO (Zen Kernel)"
iso_version="$(date +%Y.%m.%d)"
install_dir="arch"
buildmodes=('iso')
bootmodes=('bios.syslinux.mbr' 'bios.syslinux.eltorito'
           'uefi-x86_64.systemd-boot.esp' 'uefi-x86_64.systemd-boot.eltorito')
arch="x86_64"
pacman_conf="pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'xz' '-Xbcj' 'x86' '-b' '1M' '-Xdict-size' '1M')
file_permissions=(
  ["/etc/shadow"]="0:0:400"
  ["/root"]="0:0:750"
)
